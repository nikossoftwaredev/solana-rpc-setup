---
name: Core Contributor Issue
about: Create a report describing a problem and a proposed solution
title: ''
assignees: ''
---

#### Problem
<!--
  This template should only be used by core contributors. If you
  are not a core contributor, please use the "Community Issue" template
  to ensure that your issue can be triaged appropriately.
-->

#### Proposed Solution
