#!/usr/bin/env bash

set -eo pipefail

scripts/check-dev-context-only-utils.sh "$@"
